module CartoonsHelper
end
